﻿using Microsoft.AspNetCore.Components.Server.ProtectedBrowserStorage;
using System.Text.Json;

namespace BlazingBlog.Autentication
{
    public class AutenticationService
    {
        private readonly UserService _userService;
        private readonly ProtectedLocalStorage protectedLocalStorage;

        public AutenticationService(UserService userService, ProtectedLocalStorage protectedLocalStorage)
        {
            _userService = userService;
            this.protectedLocalStorage = protectedLocalStorage;
        }

        public async Task<LoggedInUser?> LoginUserAsync(LoginModel loginModel)
        {
            var loggedInUser = await _userService.loginAsync(loginModel);
            if(loggedInUser is not null)
            {
                await SaveUserToBrowserStorageAsync(loggedInUser.Value);
            }
            return loggedInUser;
        }

        private const string UserStoragekey = "blg_user";
        private JsonSerializerOptions JsonSerializerOptions = new JsonSerializerOptions
        {

        };

        public async Task SaveUserToBrowserStorageAsync(LoggedInUser user)
        {
          await protectedLocalStorage.SetAsync(UserStoragekey, JsonSerializer.Serialize(user, JsonSerializerOptions));
        }

        public async Task<LoggedInUser? > GetUserFromBrowserStorageAsync()
        {
            try
            {
                var result = await protectedLocalStorage.GetAsync<string>(UserStoragekey);
                if (result.Success && !string.IsNullOrWhiteSpace(result.Value))
                {
                    var LoggedInUser = JsonSerializer.Deserialize<LoggedInUser>(result.Value, JsonSerializerOptions);
                    return LoggedInUser;
                }

            } catch (InvalidOperationException ex)
            {
              

            }
            return null;
        }

        public async Task RemoveUserFromBroserStorageAsync() =>
        await protectedLocalStorage.DeleteAsync(UserStoragekey);
    }
}
