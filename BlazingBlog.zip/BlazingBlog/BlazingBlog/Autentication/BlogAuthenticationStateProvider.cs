﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Components.Authorization;
using System.Security.Claims;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace BlazingBlog.Autentication
{
    public class BlogAuthenticationStateProvider : AuthenticationStateProvider, IDisposable
    {

        private readonly AutenticationService _authenticationService;
        private const string BlogAuthenticationTyp = "blog-auth";
        public BlogAuthenticationStateProvider(AutenticationService authenticationService)
        {
            _authenticationService = authenticationService;
            AuthenticationStateChanged += BlogAuthenticationStateProvider_AuthenticationStateChanged;
        }

        private async void BlogAuthenticationStateProvider_AuthenticationStateChanged(Task<AuthenticationState> task)
        {
            var authState = await task;
           if (authState is not null)
            {
                var userId =Convert.ToInt32(authState.User.FindFirstValue(ClaimTypes.NameIdentifier));
                var displayName = authState.User.FindFirstValue(ClaimTypes.Name);
                LoggedInUser = new(userId, displayName!);
            }
        }

        public LoggedInUser LoggedInUser { get; private set; } = new(0, string.Empty);

        public override async Task<AuthenticationState> GetAuthenticationStateAsync()
        {
            var claimsPrincipal = new ClaimsPrincipal();
            var user = await _authenticationService.GetUserFromBrowserStorageAsync();
            if (user is not null)
            {
                var identity = new ClaimsIdentity(
                    new[]
                    {
                        new Claim(ClaimTypes.NameIdentifier, user.Value.UserId.ToString()),
                        new Claim(ClaimTypes.Name, user.Value.UserId.ToString()),
                    }, BlogAuthenticationTyp
                    
                    );
                claimsPrincipal = new(identity);
            }
             return new AuthenticationState( claimsPrincipal );   
        }

        public async Task<string?> LoginAsync(LoginModel loginModel)
        {
            var loggedInUser = await _authenticationService.LoginUserAsync(loginModel);
            if (loggedInUser is null)
            {

                return "Invalid credentials";
            }
            else
            {
                return null;
            }
           
        }
           

        public void Dispose() =>

            AuthenticationStateChanged -= BlogAuthenticationStateProvider_AuthenticationStateChanged;
    }
}
