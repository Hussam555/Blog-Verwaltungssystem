﻿using BlazingBlog.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace BlazingBlog.Services
{
    public class BlogPostServices
    {
        private readonly DataBaseContext _context;

        public BlogPostServices(DataBaseContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<BlogPost>> GetPostsAsync(bool publishedOnly = false , string? categorySlug = null)
        {
           var query =  _context.Blogs.Include(bp => bp.Category).AsNoTracking();

            if (!string.IsNullOrWhiteSpace(categorySlug))
            {
                var categoryId = await _context.Categories.AsNoTracking().Where(c=>c.Slug == categorySlug).Select(c=>c.Id).FirstOrDefaultAsync();

                if (categoryId > 0)
                {
                    query = query.Where(bp => bp.CategoryId == categoryId);

                }
            }


            if (publishedOnly)
            {

                query = query.Where(bp => bp.IsPublished);
            }

           return await query.ToListAsync();
        }
        public async Task<MethodResult> SaveAsync(BlogSaveModel saveModel)
        {
            var entity = saveModel.ToBlogEntity();

            if (entity.Id==0)
            {
                // creating a new Blog Post
                entity.Slug= entity.Slug.Slugify();
                entity.CreatedOn= DateTime.Now;
                if (entity.IsPublished)
                {
                    entity.PublishedOn = DateTime.Now;
                }
                await _context.AddAsync(entity);
                
            }
            else
            {
                // Updating an existing Blog Post


            }

            try
            {
                if (await _context.SaveChangesAsync() > 0)
                {
                    return MethodResult.Succses();
                }  else
                    return MethodResult.Failer("Unknown error occurred while saving the blog post");
            }
            catch (Exception ex)
            {
                return MethodResult.Failer(ex.Message);
                throw;
            }
        }

        public async Task<BlogPost?> GetPostBySlugAsync(string Slug) =>
            await _context.Blogs
            .AsNoTracking()
            .FirstOrDefaultAsync(bp => bp.IsPublished && bp.Slug == Slug );
    }
}
