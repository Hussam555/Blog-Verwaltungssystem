﻿using Microsoft.EntityFrameworkCore;

namespace BlazingBlog.Services
{
    public class UserService
    {
        private readonly DataBaseContext _context;

        public UserService(DataBaseContext context)
        {
            _context = context;
        }

        public async Task<LoggedInUser?> loginAsync(LoginModel loginModel)
        {
            var dbUser = await _context.Users.AsNoTracking().FirstOrDefaultAsync(c
                =>c.Email == loginModel.UserName);
            if (dbUser is not null)
            {

                // Login success
                return new LoggedInUser(dbUser.Id, $"{dbUser.FirstName} {dbUser.LastName}".Trim());
            }
            else
            {

                // Login fialid 
                return null;
            }


        }
    }
}
