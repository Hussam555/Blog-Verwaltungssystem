﻿using BlazingBlog.Data.Entities;
using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;

namespace BlazingBlog.Services
{
    public class CategoryService
    {

        private readonly DataBaseContext _context;

        public CategoryService(DataBaseContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Category>> GetAllCategory()=>
            await _context.Categories.AsNoTracking().ToListAsync(); 

        public async Task<MethodResult> SaveCategroyAsync(Category model)
        {

            try
            {
                if (model.Id > 0)
                {
                    // Update Category

                    _context.Categories.Update(model);

                }
                else
                {

                    // create Category
                    model.Slug = model.Slug.Slugify();

                    await _context.Categories.AddAsync(model);

                }
                await _context.SaveChangesAsync();
                return MethodResult.Succses();
            }
            catch (Exception ex)
            {

                // log Exception
                return MethodResult.Failer(ex.Message);
            }

        }

       

       
    }
}
