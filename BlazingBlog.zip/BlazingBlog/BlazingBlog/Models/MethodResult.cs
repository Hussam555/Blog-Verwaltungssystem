﻿namespace BlazingBlog.Models
{
    public record struct MethodResult(bool Status, string? ErrorMessage = null)
    {


        public static MethodResult Succses() => new(true);
        public static MethodResult Failer(string ErrorMessage) => new(false, ErrorMessage);


    }
}
