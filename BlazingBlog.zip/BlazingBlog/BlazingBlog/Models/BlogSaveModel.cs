﻿using BlazingBlog.Data.Entities;
using System.ComponentModel.DataAnnotations;

namespace BlazingBlog.Models
{
    public class BlogSaveModel
    {
        public int Id { get; set; }
        [Required, MaxLength(120)]
        public string Title { get; set; }

        [Required, MaxLength(150)]
        public string Slug { get; set; }

        
        public string? Content { get; set; }

        [Required, MaxLength(250)]
        public string Introduction { get; set; }

        public bool IsPublished { get; set; }
        public int CategoryId { get; set; }

        public int UserId { get; set; } 

        public BlogPost ToBlogEntity()=>
            new()
            {
                Id = Id,
                Title = Title,
                Slug = Slug,
                CategoryId = CategoryId,
                Content = Content,
                Introduction = Introduction,
                IsPublished = IsPublished,
               
            };
        
    }

}
