﻿using BlazingBlog.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace BlazingBlog.Data
{
    public class DataBaseContext: DbContext
    {

        public DataBaseContext(DbContextOptions<DataBaseContext> options) : base(options) 
        {
            
        }

        public DbSet<Category > Categories { get; set; }    

        public DbSet<BlogPost> Blogs { get; set; }
        public DbSet<User> Users { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
#if DEBUG
            optionsBuilder.LogTo(Console.WriteLine);
#endif
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<User>().HasData(
                new User
                {
                    Id = 1,
                    FirstName = "Hussam",
                    LastName="Al khatib",
                    Email="Hussam123@gmail.com",
                    Salt="djdnkslsö",
                    Hash="ssskkmlsjhffgjk/="

                }

                );
        }


    }
}
