﻿namespace BlazingBlog
{
    public static class Utilities
    {
        private static readonly string[] _colorClasses = new string[]
        {

            "primary",
            "success",
            "info",
            "danger",
            "warning",
            "dark"


        };

        public static string GetRandomColorClass() =>
            _colorClasses.OrderBy(c => Guid.NewGuid()).First();
    }
}
